package com.smhrd.model;

import lombok.Data;

@Data
public class RecipeDetailVO {
	
	private String re_code;
	private String de_text;
	private String de_url;

}
