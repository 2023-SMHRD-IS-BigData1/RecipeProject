package com.smhrd.model;

import lombok.Data;

@Data
public class IngrementVO {

	private String re_name;
	private String ingre_code;
	private String ingre_name;
}
